var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./SocialIconsControl/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./SocialIconsControl/index.ts":
/*!*************************************!*\
  !*** ./SocialIconsControl/index.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar metadata_1 = __webpack_require__(/*! ./metadata */ \"./SocialIconsControl/metadata.ts\");\n\nvar SocialIconsControl =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function SocialIconsControl() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  SocialIconsControl.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._metadataStaticContent = new metadata_1.default();\n    this._props = {};\n    this._container = document.createElement(\"div\"); //appending the _container to the main container\n\n    container.appendChild(this._container);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  SocialIconsControl.prototype.updateView = function (context) {\n    // Add code to update control view\n    this._context = context;\n    this.createOrUpdateIcons();\n  };\n\n  SocialIconsControl.prototype.createOrUpdateIcons = function () {\n    this._container.innerHTML = \"\"; //default-social-bar , circular-social-bar , button-social-bar , hower-social-bar , animatedbutton-social-bar ,glow-social-bar\n\n    this._props.socialMediaTypeFormatProperty = this._context.parameters.socialMediaTypeProperty ? this._context.parameters.socialMediaTypeProperty.raw.toString().trim() : this._metadataStaticContent.defaultSocialbar;\n    if (!this._props.socialMediaTypeFormatProperty) return;\n    this._props.facebookProperty = this._context.parameters.facebookProperty && this._context.parameters.facebookProperty.raw ? this._context.parameters.facebookProperty.raw.toString().trim() : null;\n    this._props.twitterProperty = this._context.parameters.twitterProperty && this._context.parameters.twitterProperty.raw ? this._context.parameters.twitterProperty.raw.toString().trim() : null;\n    this._props.googleProperty = this._context.parameters.googleProperty && this._context.parameters.googleProperty.raw ? this._context.parameters.googleProperty.raw.toString().trim() : null;\n    this._props.linkedinProperty = this._context.parameters.linkedinProperty && this._context.parameters.linkedinProperty.raw ? this._context.parameters.linkedinProperty.raw.toString().trim() : null;\n    this._props.youtubeProperty = this._context.parameters.youtubeProperty && this._context.parameters.youtubeProperty.raw ? this._context.parameters.youtubeProperty.raw.toString().trim() : null;\n    this._props.pinterestProperty = this._context.parameters.pinterestProperty && this._context.parameters.pinterestProperty.raw ? this._context.parameters.pinterestProperty.raw.toString().trim() : null;\n    this._props.skypeProperty = this._context.parameters.skypeProperty && this._context.parameters.skypeProperty.raw ? this._context.parameters.skypeProperty.raw.toString().trim() : null;\n    this._props.androidProperty = this._context.parameters.androidProperty && this._context.parameters.androidProperty.raw ? this._context.parameters.androidProperty.raw.toString().trim() : null;\n    this._props.dribbbleProperty = this._context.parameters.dribbbleProperty && this._context.parameters.dribbbleProperty.raw ? this._context.parameters.dribbbleProperty.raw.toString().trim() : null;\n    this._props.vimeoProperty = this._context.parameters.vimeoProperty && this._context.parameters.vimeoProperty.raw ? this._context.parameters.vimeoProperty.raw.toString().trim() : null;\n    this._props.tumblrProperty = this._context.parameters.tumblrProperty && this._context.parameters.tumblrProperty.raw ? this._context.parameters.tumblrProperty.raw.toString().trim() : null;\n    this._props.vineProperty = this._context.parameters.vineProperty && this._context.parameters.vineProperty.raw ? this._context.parameters.vineProperty.raw.toString().trim() : null;\n    this._props.foursquareProperty = this._context.parameters.foursquareProperty && this._context.parameters.foursquareProperty.raw ? this._context.parameters.foursquareProperty.raw.toString().trim() : null;\n    this._props.stumbleuponProperty = this._context.parameters.stumbleuponProperty && this._context.parameters.stumbleuponProperty.raw ? this._context.parameters.stumbleuponProperty.raw.toString().trim() : null;\n    this._props.flickrProperty = this._context.parameters.flickrProperty && this._context.parameters.flickrProperty.raw ? this._context.parameters.flickrProperty.raw.toString().trim() : null;\n    this._props.yahooProperty = this._context.parameters.yahooProperty && this._context.parameters.yahooProperty.raw ? this._context.parameters.yahooProperty.raw.toString().trim() : null;\n    this._props.redditProperty = this._context.parameters.redditProperty && this._context.parameters.redditProperty.raw ? this._context.parameters.redditProperty.raw.toString().trim() : null;\n    this._props.rssProperty = this._context.parameters.rssProperty && this._context.parameters.rssProperty.raw ? this._context.parameters.rssProperty.raw.toString().trim() : null;\n    this.onLoad();\n  };\n\n  SocialIconsControl.prototype.onLoad = function () {\n    var thisRef = this;\n    this._divBody = document.createElement(\"div\");\n    this._divBody.className = this._props.socialMediaTypeFormatProperty == this._metadataStaticContent.defaultSocialbar ? this._metadataStaticContent.circularSocialBar : this._props.socialMediaTypeFormatProperty;\n    this._ulElement = document.createElement(\"ul\");\n\n    if (this._props.socialMediaTypeFormatProperty == this._metadataStaticContent.glowSocialBar) {\n      this._ulElement.className = this._metadataStaticContent.glowSocialBar_SocialIcons;\n    }\n\n    var iClassName = \"\";\n    var anchorClassName = \"\";\n    var spanTextClassName = \"\";\n\n    switch (this._props.socialMediaTypeFormatProperty) {\n      case this._metadataStaticContent.circularSocialBar:\n        iClassName = this._metadataStaticContent.circularSocialBar_IClassName;\n        break;\n\n      case this._metadataStaticContent.buttonSocialBar:\n        iClassName = this._metadataStaticContent.buttonSocialBar_IClassName;\n        anchorClassName = this._metadataStaticContent.buttonSocialBar_AnchorClassName;\n        spanTextClassName = this._metadataStaticContent.buttonSocialBar_SpanTextClassName;\n        break;\n\n      case this._metadataStaticContent.howerSocialBar:\n        anchorClassName = this._metadataStaticContent.howerSocialBar_AnchorClassName;\n        spanTextClassName = this._metadataStaticContent.howerSocialBar_SpanTextClassName;\n        break;\n\n      case this._metadataStaticContent.animatedbuttonSocialBar:\n        iClassName = this._metadataStaticContent.animatedbuttonSocialBar_IClassName;\n        spanTextClassName = this._metadataStaticContent.animatedbuttonSocialBar_SpanTextClassName;\n        break;\n\n      case this._metadataStaticContent.glowSocialBar:\n        iClassName = this._metadataStaticContent.glowSocialBar_IClassName;\n        spanTextClassName = this._metadataStaticContent.glowSocialBar_spanTextClassName;\n        break;\n\n      default:\n        iClassName = this._metadataStaticContent.defaultSocialbar_IClassName;\n        break;\n    }\n\n    Object.keys(this._props).map(function (keyName) {\n      if (keyName != thisRef._metadataStaticContent.socialMediaTypeFormatProperty && thisRef._props[keyName] != null) {\n        var _propertyName = thisRef.propertyName(keyName);\n\n        thisRef._anchorTag = document.createElement(\"a\");\n        thisRef._anchorTag.href = thisRef._props[keyName];\n        thisRef._anchorTag.className = anchorClassName + _propertyName;\n        thisRef._anchorTag.id = thisRef._metadataStaticContent.anchorTag_id + _propertyName;\n        thisRef._anchorTag.target = thisRef._metadataStaticContent.anchorTag_target;\n\n        if (thisRef._props.socialMediaTypeFormatProperty != thisRef._metadataStaticContent.howerSocialBar) {\n          thisRef._iconTag = document.createElement(\"i\");\n          thisRef._iconTag.className = iClassName + _propertyName;\n\n          thisRef._anchorTag.appendChild(thisRef._iconTag);\n        }\n\n        if (thisRef._props.socialMediaTypeFormatProperty == thisRef._metadataStaticContent.buttonSocialBar || thisRef._props.socialMediaTypeFormatProperty == thisRef._metadataStaticContent.howerSocialBar || thisRef._props.socialMediaTypeFormatProperty == thisRef._metadataStaticContent.animatedbuttonSocialBar) {\n          thisRef._spanText = document.createElement(\"span\");\n          thisRef._spanText.className = spanTextClassName;\n          thisRef._spanText.innerHTML = _propertyName;\n\n          thisRef._anchorTag.appendChild(thisRef._spanText);\n        }\n\n        if (thisRef._props.socialMediaTypeFormatProperty == thisRef._metadataStaticContent.animatedbuttonSocialBar || thisRef._props.socialMediaTypeFormatProperty == thisRef._metadataStaticContent.glowSocialBar) {\n          thisRef._anchorTag.className = \"\";\n          thisRef._liElement = document.createElement(\"li\");\n\n          if (thisRef._props.socialMediaTypeFormatProperty == thisRef._metadataStaticContent.glowSocialBar) {\n            thisRef._liElement.className = _propertyName;\n            var textnode = document.createTextNode(_propertyName);\n\n            thisRef._anchorTag.appendChild(textnode);\n          }\n\n          thisRef._liElement.appendChild(thisRef._anchorTag);\n\n          thisRef._ulElement.appendChild(thisRef._liElement);\n        } else {\n          thisRef._divBody.appendChild(thisRef._anchorTag);\n        }\n      }\n\n      ;\n    });\n\n    if (this._props.socialMediaTypeFormatProperty == thisRef._metadataStaticContent.animatedbuttonSocialBar || this._props.socialMediaTypeFormatProperty == thisRef._metadataStaticContent.glowSocialBar) {\n      this._divBody.appendChild(this._ulElement);\n    }\n\n    this._container.appendChild(this._divBody);\n  };\n\n  SocialIconsControl.prototype.propertyName = function (property) {\n    return property.replace(this._metadataStaticContent.property, \"\");\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  SocialIconsControl.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  SocialIconsControl.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return SocialIconsControl;\n}();\n\nexports.SocialIconsControl = SocialIconsControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SocialIconsControl/index.ts?");

/***/ }),

/***/ "./SocialIconsControl/metadata.ts":
/*!****************************************!*\
  !*** ./SocialIconsControl/metadata.ts ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar MetadataStaticContent =\n/** @class */\nfunction () {\n  function MetadataStaticContent() {\n    this.property = \"Property\";\n    this.socialMediaTypeFormatProperty = \"socialMediaTypeFormatProperty\";\n    this.defaultSocialbar = \"default-social-bar\";\n    this.circularSocialBar = \"circular-social-bar\";\n    this.buttonSocialBar = \"button-social-bar\";\n    this.howerSocialBar = \"hower-social-bar\";\n    this.animatedbuttonSocialBar = \"animatedbutton-social-bar\";\n    this.glowSocialBar = \"glow-social-bar\";\n    this.anchorTag_id = \"idAnchor\";\n    this.anchorTag_target = \"_blank\";\n    this.defaultSocialbar_IClassName = \"fa box fa-\";\n    this.circularSocialBar_IClassName = \"fa cirular fa-\";\n    this.buttonSocialBar_IClassName = \"fa fa-\";\n    this.buttonSocialBar_AnchorClassName = \"btn btn-icon btn-\";\n    this.buttonSocialBar_SpanTextClassName = \"text-design\";\n    this.howerSocialBar_AnchorClassName = \"icon \";\n    this.howerSocialBar_SpanTextClassName = \"\";\n    this.animatedbuttonSocialBar_IClassName = \"fa fa-\";\n    this.animatedbuttonSocialBar_SpanTextClassName = \"\";\n    this.glowSocialBar_IClassName = \"fa fa-fw fa-\";\n    this.glowSocialBar_spanTextClassName = \"\";\n    this.glowSocialBar_SocialIcons = \"socialIcons\";\n  }\n\n  return MetadataStaticContent;\n}();\n\nexports.default = MetadataStaticContent;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SocialIconsControl/metadata.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PCFControls.SocialIconsControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SocialIconsControl);
} else {
	var PCFControls = PCFControls || {};
	PCFControls.SocialIconsControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SocialIconsControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}